import type { InventoryItem } from '../types';

export const initialInventoryItems: InventoryItem[] = [
    { id: 'PROD-001', name: 'كاميرا مراقبة خارجية 4K', sku: 'CAM-4K-01', category: 'كاميرات مراقبة', quantity: 25, reorderPoint: 10, supplierId: 'S-001', costPrice: 350, sellingPrice: 550, status: 'متوفر', salesVelocity: 15, leadTimeDays: 7 },
    { id: 'PROD-002', name: 'جهاز تسجيل شبكي (NVR) 16 قناة', sku: 'NVR-16CH-01', category: 'أجهزة تسجيل', quantity: 8, reorderPoint: 5, supplierId: 'S-001', costPrice: 1200, sellingPrice: 1800, status: 'كمية قليلة', salesVelocity: 5, leadTimeDays: 10 },
    { id: 'PROD-003', name: 'شاشة عرض 55 بوصة', sku: 'DISP-55-LG', category: 'شاشات عرض', quantity: 15, reorderPoint: 5, supplierId: 'S-002', costPrice: 1500, sellingPrice: 2200, status: 'متوفر', salesVelocity: 8, leadTimeDays: 14 },
    { id: 'PROD-004', name: 'عقد صيانة سنوي', sku: 'SRV-MAINT-01', category: 'خدمات', quantity: 999, reorderPoint: 0, supplierId: 'S-004', costPrice: 40000, sellingPrice: 75000, status: 'متوفر', salesVelocity: 2, leadTimeDays: 0 },
    { id: 'PROD-005', name: 'محول شبكة (Switch) 24 منفذ', sku: 'SW-24P-CISC', category: 'معدات شبكات', quantity: 3, reorderPoint: 5, supplierId: 'S-003', costPrice: 800, sellingPrice: 1100, status: 'نفذ المخزون', salesVelocity: 10, leadTimeDays: 12 },
];
